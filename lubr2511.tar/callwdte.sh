: 
# @(#) Tran-Text-File
# '    ---------------
:
#
#
                tr -s '[:blank:]' < $1 > tmp/$$xx
                mv tmp/$$xx $1
                sed 's/ ;/;/g' < $1 > tmp/$$xx
                mv tmp/$$xx $1
                sed 's/; /;/g' < $1 > tmp/$$xx
                mv tmp/$$xx $1
#               sed 's/^ //g' < $1 > tmp/$$xx
#               mv tmp/$$xx $1
#               sed 's/\//g' < $1 > tmp/$$xx
#               mv tmp/$$xx $1
